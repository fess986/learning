import styled from "styled-components";

const Li = styled.li`
  list-style: none;
`;

export default Li;
