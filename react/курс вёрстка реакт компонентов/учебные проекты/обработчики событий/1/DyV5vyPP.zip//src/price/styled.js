import styled from "styled-components";

export const StyledPrice = styled.span`
  font-size: 28px;
  font-weight: bold;
  line-height: 1;
`;
