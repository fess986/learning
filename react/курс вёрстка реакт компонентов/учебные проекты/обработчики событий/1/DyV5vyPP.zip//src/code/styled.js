import styled from "styled-components";

export const StyledCode = styled.span`
  color: #888;
  font-size: 12px;
`;

export default StyledCode;
