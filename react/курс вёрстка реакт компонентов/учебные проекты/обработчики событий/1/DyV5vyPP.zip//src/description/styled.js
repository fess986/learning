import styled from "styled-components";
import Button from "/src/button/button";

export const DescriptionButton = styled(Button)`
  margin-top: 20px;
`;
