import styled from "styled-components";

const P = styled.p`
  padding: 0;
  margin: 0;
`;

export default P;
