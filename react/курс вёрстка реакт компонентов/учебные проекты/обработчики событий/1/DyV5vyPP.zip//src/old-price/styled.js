import styled from "styled-components";

export const StyledOldPrice = styled.del`
  font-size: 18px;
  color: #888;
  line-height: 1;
`;
