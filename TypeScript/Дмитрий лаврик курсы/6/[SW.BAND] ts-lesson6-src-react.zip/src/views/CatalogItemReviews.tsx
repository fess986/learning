export default function CatalogItemReviews(){
	return <div>
		<h1>Catalog Item Reviews</h1>
	</div>
}