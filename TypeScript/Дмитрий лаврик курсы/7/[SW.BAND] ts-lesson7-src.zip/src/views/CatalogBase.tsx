import { Outlet } from 'react-router-dom';

export default function Catalog(){
	return <div>
		<h1>Catalog</h1>
		<Outlet />
	</div>
}