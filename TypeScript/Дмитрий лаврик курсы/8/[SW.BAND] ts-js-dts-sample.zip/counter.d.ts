export declare function setupCounter(element: HTMLElement): (value: number) => void
