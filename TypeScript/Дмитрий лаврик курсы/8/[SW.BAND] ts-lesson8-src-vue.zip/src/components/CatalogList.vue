<template>
	<div>
		<h1>Catalog list</h1>
		<div>
			<strong>Count: {{ cnt }}</strong>
			<button class="btn btn-success" type="button" @click="inc">+ {{ step }}</button>
		</div>
		<ul v-if="request.success">
			<li v-for="pr in request.data">
				{{ pr.title }}
			</li>
		</ul>
		<div v-else-if="!request.done">
			Loading....
		</div>
	</div>
</template>
<script setup lang="ts">
	import { ref } from 'vue'
	import useApiRequest from './../composables/useApiRequest'

	interface CatalogListProps{
		step: number
	}
	
 	const request = useApiRequest('products.all');

	const props = defineProps<CatalogListProps>();
	const emit = defineEmits<{
		(name: 'changed', value: number): void
	}>();
	
	const cnt = ref(0);

	function inc(){
		cnt.value += props.step;
		emit('changed', cnt.value);
	}
</script>