<template>
	<div>
		<h1>Catalog list</h1>
		<div>
			<strong>Count: {{ cnt }}</strong>
			<button class="btn btn-success" type="button" @click="inc">+ {{ step }}</button>
		</div>
	</div>
</template>
<script setup lang="ts" generic="T extends number | string">
	import { UnwrapRef, ref } from 'vue'

	interface CatalogListProps{
		initial: T,
		step: T
	}

	const props = defineProps<CatalogListProps>();
	const emit = defineEmits<{
		(name: 'changed', value: T): void
	}>();
	
	const cnt = ref(props.initial);

	function inc(){
		if(typeof cnt.value === 'number' && typeof props.step === 'number'){
			cnt.value = cnt.value + props.step as UnwrapRef<T>;
		}
		else{
			cnt.value = `${cnt.value}.${props.step}` as UnwrapRef<T>;
		}

		emit('changed', cnt.value as T);
	}
</script>