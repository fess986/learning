import type { InjectionKey } from 'vue'
import { TApi } from '../api'

export const apiInject = Symbol() as InjectionKey<TApi>