import { ref, UnwrapRef } from "vue";
import { TApi, TApiKeys } from "../api";
import { getByDotKey, runFnWithTuple } from "../shared/objects";
import { GetByDotKey } from "../types/utility";
import useApi from "./useApi";

export default function useApiRequest<T extends TApiKeys>(
	schema: T, 
	...params: Parameters<GetByDotKey<TApi, T>>
){
	const api = useApi();
	const fn = getByDotKey(api, schema);
	type Data = Awaited<ReturnType<typeof fn>>;

	const result = ref<ApiRequestResult<Data>>({
		done: false,
		success: false,
		data: null,
		error: null
	})
	
	runFnWithTuple(fn, params)
		.then(data => result.value = {
			done: true,
			success: true,
			data: data as UnwrapRef<Data>,
			error: null
		})
		.catch((e: Error) => result.value = {
			done: true,
			success: false,
			data: null,
			error: e
		});

	return result;
}

type ApiRequestLoading = {
	done: false,
	success: false,
	data: null,
	error: null
}

type ApiRequestDone<T> = {
	done: true,
	success: true,
	data: T,
	error: null
}

type ApiRequestError = {
	done: true,
	success: false,
	data: null,
	error: Error
}

type ApiRequestResult<T> = ApiRequestLoading | ApiRequestDone<T> | ApiRequestError;