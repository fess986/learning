import { inject } from 'vue'
import { apiInject } from '../types/injects';

export default function useApi(){
	const api = inject(apiInject);

	if(api != null){
		return api;
	}

	throw new Error('Some moron run app without app.provide(api)');
}