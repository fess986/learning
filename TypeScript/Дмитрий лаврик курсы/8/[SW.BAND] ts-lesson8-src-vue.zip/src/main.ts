import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import createApi from './api'
import createHttp from './api/http'
import { apiInject } from './types/injects'

const http = createHttp('http://faceprog.ru/reactcourseapi');
const api = createApi(http)

createApp(App).provide(apiInject, api).mount('#app')
